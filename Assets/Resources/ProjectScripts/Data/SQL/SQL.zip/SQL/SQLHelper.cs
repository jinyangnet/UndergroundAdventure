using UnityEngine;
using System;
using System.Collections;
using Mono.Data.Sqlite;

using System.Data;
//using Mono.Data.Sqlite;

public class SQLHelper
{
    private static  SqliteConnection  _sqliteConnection;
	
    private static SqliteCommand     _sqliteCommand;
    private static SqliteDataReader  _sqliteDataReader;
	
	//private static  SQLHelper _slqhelper ;

    public static void connectData ()
    {
		try
   		 {
			//string _file= "file:SqliteTest.db";
			//string _filename = "URI=file:"+  Application.streamingAssetsPath+"/data5.sqlite3";
			string _filename ="data source=" + Application.streamingAssetsPath + "/data5.sqlite3";
			//string _filename = "data source=" + Application.dataPath  + "/data3.sqlite3";
			//Debug.Log ( "Application.persistentDataPath="+ Application.persistentDataPath ) ;
        	//Debug.Log ( _filename ) ;
			
			_sqliteConnection = new SqliteConnection (_filename);
       	 	_sqliteConnection.Open ();
       		//Debug.Log ("Connected to db");
		 }
    	catch(Exception e)
    	{
       		string ex = e.ToString();
       		Debug.Log(ex);
    	}
    }
	
    public static void closeConnection___ ()
    {
        if (_sqliteCommand != null) 
		{
            _sqliteCommand.Dispose ();
			_sqliteCommand = null;
        }
        
		
        if (_sqliteDataReader != null) 
		{
            _sqliteDataReader.Dispose ();
			_sqliteDataReader = null;
        }

        
        if (_sqliteConnection != null) {
            _sqliteConnection.Close ();
			_sqliteConnection = null;
        }
        Debug.Log ("Disconnected from db.");
    }
	
	
	#region SQLEXEC
	/// <summary>
	/// Executes the query.
	/// </summary>
	/// <returns>
	/// The query.
	/// </returns>
	/// <param name='sqlQuery'>
	/// Sql query.
	/// </param>
    public static SqliteDataReader executeReader (string sqlQuery)
    {
		//Debug.Log ( sqlQuery );
		if(_sqliteConnection ==null)
		{
			SQLHelper.connectData();
		}
		using(_sqliteCommand = _sqliteConnection.CreateCommand () )
		{
	        _sqliteCommand.CommandText = sqlQuery;
		   _sqliteDataReader = _sqliteCommand.ExecuteReader ();
	        return _sqliteDataReader ;
		}
    }
	
	public static int executeNonQuery (string sqlQuery)
    {
		//Debug.Log ( sqlQuery );
	   
		if(_sqliteConnection ==null  )
		{
			SQLHelper.connectData();
		}
		
		using(_sqliteCommand = _sqliteConnection.CreateCommand () )
		{
	        //_sqliteCommand = _sqliteConnection.CreateCommand ();
	        _sqliteCommand.CommandText = sqlQuery;
		    int  i = _sqliteCommand.ExecuteNonQuery ();
	        //_sqliteCommand = null;
	        return i ;
		}
    }
	
	
    public static System.Object ExecuteScalar (string sqlQuery)
    {
		 Debug.Log ( sqlQuery );
		if(_sqliteConnection ==null)
		{
			SQLHelper.connectData();
		}
		
		using(_sqliteCommand = _sqliteConnection.CreateCommand () )
		{
        //_sqliteCommand = _sqliteConnection.CreateCommand ();
	        _sqliteCommand.CommandText = sqlQuery;
		    System.Object _object = _sqliteCommand.ExecuteScalar ();
	        return _object ;
		}
    }
	
	
	//
	
	#endregion
	
	
	
	// SqliteException: The database file is locked
    public static SqliteDataReader selectData (string sql)
    {
        //string query = " SELECT * FROM " + sql;
        return executeReader (sql);
    }
	
	/// <summary>******************************************************


	#region insert
    public static int insert (string tableName, string[] values)
    {
        string sql = "INSERT INTO " + tableName + " VALUES (" + values[0];
        for (int i = 1; i < values.Length; ++i) {
            sql += ", " + values[i];
        }
        sql += ")";
		
		//Debug.Log(sql);
		
        return SQLHelper.executeNonQuery (sql);
    }
	
	public static int insert (string sql)
    {
        return SQLHelper.executeNonQuery (sql);
    }
	#endregion 
	
	#region  update
	
	public static SqliteDataReader update (string tableName, string []cols,string []colsvalues,string selectkey,string selectvalue)
	{
		string sql = "UPDATE "+tableName+" SET "+cols[0]+" = "+colsvalues[0];
		for (int i = 1; i < colsvalues.Length; ++i) {
		 	 sql += ", " +cols[i]+" ="+ colsvalues[i];
		}
		sql += " WHERE "+selectkey+" = "+selectvalue+" ";
		return executeReader (sql);
	}
	
	public static int update ( string sql )
	{
		return SQLHelper.executeNonQuery (sql);
	}
	
	#endregion
	
	public static SqliteDataReader delete(string tableName,string []cols,string []colsvalues)
	{
			string sql = "DELETE FROM "+tableName + " WHERE " +cols[0] +" = " + colsvalues[0];
			for (int i = 1; i < colsvalues.Length; ++i) {
		 	    sql += " or " +cols[i]+" = "+ colsvalues[i];
			}
		
		//Debug.Log(sql);
		
		return executeReader (sql);
	}
	
    public static SqliteDataReader insert (string tableName, string[] cols, string[] values)
    {

        if (cols.Length != values.Length) {
            throw new SqliteException ("columns.Length != values.Length");
        }

        string query = "INSERT INTO " + tableName + "(" + cols[0];
        for (int i = 1; i < cols.Length; ++i) {
            query += ", " + cols[i];
        }

        query += ") VALUES (" + values[0];
        for (int i = 1; i < values.Length; ++i) {
            query += ", " + values[i];
        }
        query += ")";
        return executeReader (query);

    }



    public static SqliteDataReader DeleteContents (string tableName)
    {
        string query = " DELETE FROM " + tableName;
        return executeReader (query);
    }
}