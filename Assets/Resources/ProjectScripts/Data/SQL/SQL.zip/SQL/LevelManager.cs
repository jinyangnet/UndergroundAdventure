using UnityEngine;
using System.Collections;

public class LevelManager : MonoBehaviour {
	
	public GameObject _bottom ;
	public GameObject _clicken ;
	public GameObject _sheep_a ;
	public GameObject _stone_cicle_a ;
	public GameObject _stone_rectangle_a ;
	public GameObject _stone_rectangle_b ;
	public GameObject _stone_triangle_a ;
	public GameObject _stone_triangle_b ;
	public GameObject _target ;
	public GameObject _wood_cicle_a ;
	public GameObject _wood_cicle_b ;
	public GameObject _wood_rectangle_a ;
	public GameObject _wood_rectangle_b ;
	public GameObject _wood_rectangle_c ;
	public GameObject _wood_rectangle_d ;
	public GameObject _wood_rectangle_e ;
	public GameObject _wood_triangle_a ;
	public GameObject _wood_triangle_b ;
	public GameObject _wood_triangle_c ;
	public GameObject _wood_triangle_d ;
	public GameObject _wood_triangle_e ;
	
	public GameObject _star ;

	public static LevelManager _LM ;
	void Awake ()
	{
		_LM = this ;
	}
	
	
	void Start () {
		
		InitGameObjectsData();
	
	}
	
	// Use this for initialization
	public  void InitGameObjectsData () {
		
		//if( GameState.IsEditing )
		//	return ;
		if( GameState.GameLevelsIndex <= 0)
		{
			GameState.GameLevelsIndex = 1 ;
		}
		
		SQLManager.InitLevelDetailedData(GameState.GameLevelsIndex) ;
		print( "init level , levelindex = " + GameState.GameLevelsIndex +" count= "+ SQLManager.GameObjectsDataList.Count);
		float transformZ = 2.0f ;
		for(int i =0 ;i< SQLManager.GameObjectsDataList.Count ;i++ )
		{
			//print( 0 );
			GameObjectDetailedMode gb = SQLManager.GameObjectsDataList[i] ;
			//print( 1 );
			GameObject _gameobjectTemp ;
			GetGameObject(gb.prefabName,out _gameobjectTemp ) ;
			
			if(gb.prefabName.Contains("sheep"))
			{
				transformZ = 5.0f ;
			}
			else
			{
				transformZ = 2.0f;
			}
			
			GameObject _gameobject  =(GameObject)Instantiate(_gameobjectTemp);
			_gameobject.transform.position =new Vector3(gb.transformX,gb.transformY,transformZ );
			_gameobject.transform.rotation =new Quaternion(gb.rotateX,gb.rotateY,gb.rotateZ ,gb.rotateW ) ;
			_gameobject.transform.localScale =new Vector3(gb.scaleX,gb.scaleY,gb.scaleZ );
			
			//print( i );
		}
	}
	
	
	void OnSelectionChange (string val)
	{
		int levelindex = System.Convert.ToInt32(val) ;
		GameState.GameLevelsIndex = levelindex ;
		
		Debug.Log( " LevelManager OnSelectionChange GameState.LevelCurrentIndex = "+ levelindex +"IsEditing="+GameState.IsEditing );
		
		if( !GameState.IsEditing )
		{
			InitGameObjectsData() ;
		}
		
		// Camera maincamera = FindCamera();
		// mainCamera.SendMessage("init",val,SendMessageOptions.DontRequireReceiver );
	}
	
	//
	
	
	//OnSelectionChange
	
	
	public void  GetGameObject( string name,out  GameObject _gameobject)
	{
		name =name.Replace("(","").Replace(")","").Replace("Clone","");
		switch(name)
		{
			case "bottom":
				 _gameobject = _bottom;
				break ;
			
			case "clicken":
				 _gameobject = _clicken;
				break;
				
		    case "sheep":
			case "sheep_a":
				_gameobject = _sheep_a;
				break;
			
			case "star":
			case "star_a":
				_gameobject = _star ;
				break;
				
			case "stone_cicle_a":
				_gameobject = _stone_cicle_a;
				break;
					
			case "stone_rectangle_a":
				_gameobject = _stone_rectangle_a;
				break;
				
			case "stone_rectangle_b":
			 	_gameobject = _stone_rectangle_b ;
				break;
				
			case "stone_triangle_a":
				_gameobject = _stone_triangle_a ;
				break;
				
			case "stone_triangle_b":
				_gameobject = _stone_triangle_b ;
				break;
				
			case "target":
				_gameobject = _target ;
				break;
				
			case "wood_cicle_a":
				_gameobject = _wood_cicle_a ;
				break;
				
			case "wood_cicle_b":
				_gameobject = _wood_cicle_b ;
				break;
				
			case "wood_rectangle_a":
				_gameobject = _wood_rectangle_a ;
				break;
				
			case "wood_rectangle_b":
				_gameobject = _wood_rectangle_b ;
				break;
				
			case "wood_rectangle_c":
				_gameobject = _wood_rectangle_c ;
				break;
				
			case "wood_rectangle_d":
				_gameobject = _wood_rectangle_d ;
				break;
				
			case "wood_rectangle_e":
				_gameobject = _wood_rectangle_e ;
				break;
				
			case "wood_triangle_a":
				_gameobject = _wood_triangle_a ;
				break;
				
			case "wood_triangle_b":
				_gameobject = _wood_triangle_b ;
				break;
				
			case "wood_triangle_c":
				_gameobject = _wood_triangle_c ;
				break;
				
			case "wood_triangle_d":
				_gameobject = _wood_triangle_d ;
				break;
				
			case "wood_triangle_e":
				_gameobject = _wood_triangle_e ;
				break;
			
			//_star
			
			default:
			     Debug.Log("name===="+ name);
				_gameobject = _wood_triangle_e ;
			   break;
			
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
